#!/usr/local/bin/perl

use	strict;
use	warnings;

my	$clk_f;		# Clock Frequency.
my	$clk_p;		# Clock Period.
my	$clk_name;	# Clock Name.
my	$rst_name;	# Reset Name.

## Clock Setting.
# print	"Insert Target CLK Freq.(GHz) : \n";
# $clk_f = <stdin>;
$clk_f = "1";
chomp	$clk_f;		# Remove \n behind $clk_f.
$clk_p = 1/$clk_f;

## Clock and Reset Name.
# print	"Clock Port Name : \n";
# $clk_name = <stdin>;
$clk_name = "clk";
chomp	$clk_name;

# print	"Reset Port Name : \n";
# $rst_name = <stdin>;
$rst_name = "reset";
chomp	$rst_name;

open	my $clk_info, '>', './INFO/Clk_information';
	
	## Write clock information.
	print {$clk_info} "Clk freq. : $clk_f\n";
	print {$clk_info} "Clk period : $clk_p\n";
	print {$clk_info} "Clk name : $clk_name\n";
	print {$clk_info} "Reset name : $rst_name\n";

close	$clk_info;
