#!/usr/local/bin/perl

use	strict;
use	warnings;

my	$top_name;
my	$rtl_path = "./RTL/";
my	$sub_m_name;
my	$sub_count = 0;

## Top Module Setting.
# print	"Type Top Module Name :\n";
# $top_name = <stdin>;
$top_name = "top";

chomp	$top_name;	# Remove \n behind $top_name.

open	my $top_info, '>', './INFO/Module_hierarchy';
	
	## Write Top module information.
	print {$top_info} "Top module name : $top_name\n";


open	my $top_verilog, '<', $rtl_path.$top_name.'.v' || die "Failed to open top module verilog.\n";
	while(my $top_module_file = <$top_verilog>){

		opendir (dirHandle, $rtl_path) || die "Failed to get verilog files.\n";
			while($sub_m_name = readdir(dirHandle)){

				# Use regular expression to ignore files beginning with a period.
				next if($sub_m_name =~ m/^\./);
				next if($sub_m_name =~ m/$top_name/);

				$sub_m_name =~ s/.v//;

				if($top_module_file =~ m/$sub_m_name/){
					$sub_count = $sub_count + 1;
					print {$top_info} "Sub module $sub_count : $sub_m_name\n";
				}
			}
		closedir (dirHandle);
	}
close	$top_verilog;

print {$top_info} "The number of Sub module : $sub_count\n";	

close	$top_info;
