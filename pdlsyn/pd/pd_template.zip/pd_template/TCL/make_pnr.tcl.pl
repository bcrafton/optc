#!/usr/local/bin/perl

use	strict;
use	warnings;

my	$rtl_path = "./RTL/";		# RTL path for perl script.
my	$syn_rtl_path = "../RTL/";	# RTL path for synthesis.
my	$syn_path = "../SYN/";		# SYN path for PNR.
my	$verilog_files;			# Name of verilog files.
## Tech. Information.
my	$tech_name;
my	$db_path;
my	$db_name;
my	$tech_lef_path;
my	$tech_lef;
my	$cell_lef_path;
my	$cell_lef;
my	$cell_lib_path;
my	$cell_lib;
my	$cap_tbl;
my	$cell_list;
## Top Module Information.
my	$top_name;
## Clock Information.
my	$clk_freq;
my	$clk_freq_mhz;
my	$clk_period;
my	$clk_name;
my	$rst_name;

## Read Technology Information.
open	my $tech_info, '<', './INFO/Tech_information' || die "Failed to open tech. information file.\n";
	while(my $tech_tmp = <$tech_info>){
		if($tech_tmp =~ m/^Tech name/){		# Tech name.
			chomp $tech_tmp;
			$tech_tmp =~ s/^Tech name : //;
			$tech_name = $tech_tmp;
		}elsif($tech_tmp =~ m/^DB path/){	# DB path.
			chomp $tech_tmp;
			$tech_tmp =~ s/^DB path : //;
			$db_path = $tech_tmp;
		}elsif($tech_tmp =~ m/^DB name/){	# DB name.
			chomp $tech_tmp;
			$tech_tmp =~ s/^DB name : //;
			$db_name = $tech_tmp;
		}elsif($tech_tmp =~ m/^Tech lef path/){	# Tech. lef path.
			chomp $tech_tmp;
			$tech_tmp =~ s/^Tech lef path : //;
			$tech_lef_path = $tech_tmp;
		}elsif($tech_tmp =~ m/^Tech lef/){	# Tech. lef.
			chomp $tech_tmp;
			$tech_tmp =~ s/^Tech lef : //;
			$tech_lef = $tech_tmp;
		}elsif($tech_tmp =~ m/^Cell lef path/){	# Cell lef path.
			chomp $tech_tmp;
			$tech_tmp =~ s/Cell lef path : //;
			$cell_lef_path = $tech_tmp;
		}elsif($tech_tmp =~ m/^Cell lef/){	# Cell lef.
			chomp $tech_tmp;
			$tech_tmp =~ s/^Cell lef : //;
			$cell_lef = $tech_tmp;
		}elsif($tech_tmp =~ m/^Cell lib path/){	# Cell lib path.
			chomp $tech_tmp;
			$tech_tmp =~ s/^Cell lib path : //;
			$cell_lib_path = $tech_tmp;
		}elsif($tech_tmp =~ m/^Cell lib/){	# Cell lib.
			chomp $tech_tmp;
			$tech_tmp =~ s/Cell lib : //;
			$cell_lib = $tech_tmp;
		}elsif($tech_tmp =~ m/^Cap table/){	# Cap table.
			chomp $tech_tmp;
			$tech_tmp =~ s/^Cap table : //;
			$cap_tbl = $tech_tmp;
		}elsif($tech_tmp =~ m/^Cell list/){	# Cell list.
			chomp $tech_tmp;
			$tech_tmp =~ s/^Cell list : //;
			$cell_list = $tech_tmp;
		}else{
			print	"$tech_tmp\n";
			die "Failed to read tech. information file.\n";
		}
	}
close	$tech_info;
## Read Top Module Name.
open	my $top_m_info, '<', './INFO/Module_hierarchy' || die "Failed to open top module information file.\n";
	while(my $top_tmp = <$top_m_info>){
		chomp $top_tmp;
		if($top_tmp =~ m/Top module name/){
			$top_tmp =~ s/Top module name : //;
			$top_name = $top_tmp;
		}
	}
close	$top_m_info;
## Read Clock Information.
open	my $clk_info, '<', './INFO/Clk_information' || die "Failed to open clock information file.\n";
	while(my $clk_tmp = <$clk_info>){
		if($clk_tmp =~ m/^Clk freq./){		# Clock frequency.
			chomp $clk_tmp;
			$clk_tmp =~ s/^Clk freq. : //;
			$clk_freq = $clk_tmp;
		}elsif($clk_tmp =~ m/^Clk period/){	# Clock period.
			chomp $clk_tmp;
			$clk_tmp =~ s/^Clk period : //;
			$clk_period = $clk_tmp;
		}elsif($clk_tmp =~ m/^Clk name/){	# Clock name.
			chomp $clk_tmp;
			$clk_tmp =~ s/^Clk name : //;
			$clk_name = $clk_tmp;
		}elsif($clk_tmp =~ m/^Reset name/){	# Reset name.
			chomp $clk_tmp;
			$clk_tmp =~ s/^Reset name : //;
			$rst_name = $clk_tmp;
		}else{
			die "Failed to read clock information file.\n";
		}
	}
	$clk_freq_mhz = $clk_freq * 1000;
close	$clk_info;		
	
## Write P&R Run File.
open	my $pnr_f, '>', './PNR/pnr.tcl';
	## Set input verilog file.(Synthesis result)
	print {$pnr_f} "set init_verilog\t\t../SYN/$top_name"."_SYN.v\n";
	print {$pnr_f} "set init_lef_file\t\t[list\t\\\n";
	print {$pnr_f} "\t\t\t\t\t$tech_lef_path"."$tech_lef \\\n";
	print {$pnr_f} "\t\t\t\t\t$cell_lef_path"."$cell_lef \\\n";
	print {$pnr_f} "\t\t\t\t]\n";
	## Set top cell name.
	print {$pnr_f} "set init_top_cell\t\t$top_name\n";
	print {$pnr_f} "create_rc_corner\t\t-name\tcurRC \\\n";
	print {$pnr_f} "\t\t\t\t-T\t\t25 \\\n";
	## Set cap table.
	print {$pnr_f} "\t\t\t\t-cap_table\t$cap_tbl\n";
	## Set library files. - Timing.
	print {$pnr_f} "create_library_set\t\t-name\t\tcurLib \\\n";
	print {$pnr_f} "\t\t\t\t-timing\t$cell_lib_path"."$cell_lib\n";
	print {$pnr_f} "create_delay_corner\t\t-name\t\tcurDel \\\n";
	print {$pnr_f} "\t\t\t\t-library_set\tcurLib \\\n";
	print {$pnr_f} "\t\t\t\t-rc_corner\tcurRC\n";
	print {$pnr_f} "create_constraint_mode\t\t-name\t\tcurCon \\\n";
	print {$pnr_f} "\t\t\t\t-sdc_files\t$syn_path"."$top_name"."_SYN.sdc\n";
	print {$pnr_f} "create_analysis_view\t\t-name\t\tcurAna \\\n";
	print {$pnr_f} "\t\t\t\t-constraint_mode\tcurCon \\\n";
	print {$pnr_f} "\t\t\t\t-delay_corner\t\tcurDel\n";
	print {$pnr_f} "init_design\t\t\t-setup\t\tcurAna \\\n";
	print {$pnr_f} "\t\t\t\t-hold\t\tcurAna\n\n";
	## Floorplan.
	print {$pnr_f} "floorplan\t\t-r\t1 0.7 1 1 1 1\n\n";
	## Set place mode.
	print {$pnr_f} "setPlaceMode\t\t-wireLenOptEffort\thigh\n";
	print {$pnr_f} "setPlaceMode\t\t-dptFlow\t\ttrue\n";
	print {$pnr_f} "setPlaceMode\t\t-colorAwareLegal\ttrue\n";
	## Set nano route mode.
	print {$pnr_f} "setNanoRouteMode\t-routeBottomRoutingLayer\t1\n";
	print {$pnr_f} "setNanoRouteMode\t-routeTopRoutingLayer\t\t6\n";
	print {$pnr_f} "setNanoRouteMode\t-routeConcurrentMinimizeViaCountEffort\thigh\n";
	print {$pnr_f} "setNanoRouteMode\t-drouteUseMultiCutViaEffort\tlow\n";
	## Set opt mode.
	print {$pnr_f} "setOptMode\t\t-powerEffort\t\thigh\n";
	print {$pnr_f} "setOptMode\t\t-leakageToDynamicRatio\t0\n";
	## Place Design.
	print {$pnr_f} "setPlaceMode\t\t-placeIoPins\t\ttrue\n";
	print {$pnr_f} "setOptMode\t\t-preserveAssertions\ttrue\n";
	print {$pnr_f} "setOptMode\t\t-addInstancePrefix\tplaceopt_\n";
	print {$pnr_f} "setPinAssignMode\t-minLayer\t1 \\\n";
	print {$pnr_f} "\t\t\t-maxLayer\t6\n";
	print {$pnr_f} "createPinGroup\t\tpinG\t\t\\\n";
	print {$pnr_f} "\t\t\t-pin\t*\t\\\n";
	print {$pnr_f} "\t\t\t-optimizeOrder\n";
	print {$pnr_f} "createPinGuide\t\t-edge\t\t0\t\t\\\n";
	print {$pnr_f} "\t\t\t-pinGroup\tpinG\t\t\\\n";
	print {$pnr_f} "\t\t\t-layer\t\t{1 2 3 4 5 6}\n";
	print {$pnr_f} "createPinGuide\t\t-edge\t\t1\t\t\\\n";
	print {$pnr_f} "\t\t\t-pinGroup\tpinG\t\t\\\n";
	print {$pnr_f} "\t\t\t-layer\t\t{1 2 3 4 5 6}\n";
	print {$pnr_f} "createPinGuide\t\t-edge\t\t2\t\t\\\n";
	print {$pnr_f} "\t\t\t-pinGroup\tpinG\t\t\\\n";
	print {$pnr_f} "\t\t\t-layer\t\t{1 2 3 4 5 6}\n";
	print {$pnr_f} "createPinGuide\t\t-edge\t\t3\t\t\\\n";
	print {$pnr_f} "\t\t\t-pinGroup\tpinG\t\t\\\n";
	print {$pnr_f} "\t\t\t-layer\t\t{1 2 3 4 5 6}\n";
	print {$pnr_f} "place_opt_design\n";
	print {$pnr_f} "assignPtnPin\n";
	
	## CTS.
	print {$pnr_f} "set vars(tech,cts_buffer_cells)\t[list\t\\\n";
	open	my $buf_list, '<', './INFO/Buffer_list' || die "Failed to open buffer list.\n";
		while(my $buf_name = <$buf_list>){
			chomp $buf_name;
			print {$pnr_f} "\t\t\t\t\t\t$buf_name \\\n";
		}
	print {$pnr_f} "\t\t\t\t\t]\n";
		
	print {$pnr_f} "set vars(tech,cts_inverter_cells)\t[list\t\\\n";
	open	my $inv_list, '<', './INFO/Inverter_list' || die "Failed to open inverter list.\n";
		while(my $inv_name = <$inv_list>){
			chomp $inv_name;
			print {$pnr_f} "\t\t\t\t\t\t$inv_name \\\n";
		}
	print {$pnr_f} "\t\t\t\t\t]\n";
	
	## Timing.
	print {$pnr_f} "setOptMode\t\t-addInstancePrefix\tccpot_\n";
	
	print {$pnr_f} "setAnalysisMode\t\t-analysisType\t\tonChipVariation \\\n";
	print {$pnr_f} "\t\t\t-cpp\t\t\tboth\n";

	print {$pnr_f} "create_route_type\t-name\t\t\t\ttop\t\\\n";
	print {$pnr_f} "\t\t\t-preferred_routing_layer_effort\tmedium\t\\\n";
	print {$pnr_f} "\t\t\t-top_preferred_layer\t\t6\t\\\n";
	print {$pnr_f} "\t\t\t-bottom_preferred_layer\t\t5\n";
	print {$pnr_f} "create_route_type\t-name\t\t\t\ttrunk\t\\\n";
	print {$pnr_f} "\t\t\t-preferred_routing_layer_effort\tmedium\t\\\n";
	print {$pnr_f} "\t\t\t-top_preferred_layer\t\t4\t\\\n";
	print {$pnr_f} "\t\t\t-bottom_preferred_layer\t\t3\n";
	print {$pnr_f} "create_route_type\t-name\t\t\t\tleaf\t\\\n";
	print {$pnr_f} "\t\t\t-preferred_routing_layer_effort\tmedium\t\\\n";
	print {$pnr_f} "\t\t\t-top_preferred_layer\t\t2\t\\\n";
	print {$pnr_f} "\t\t\t-bottom_preferred_layer\t\t1\n";

	print {$pnr_f} "set_ccopt_property\troute_type\t-net_type\ttop\ttop\n";
	print {$pnr_f} "set_ccopt_property\troute_type\t-net_type\ttrunk\ttrunk\n";
	print {$pnr_f} "set_ccopt_property\troute_type\t-net_type\tleaf\tleaf\n";
	print {$pnr_f} "set_ccopt_property\tbuffer_cells\t\$vars(tech,cts_buffer_cells)\n";
	print {$pnr_f} "set_ccopt_property\tinverter_cells\t\$vars(tech,cts_inverter_cells)\n";
	print {$pnr_f} "set_ccopt_property\ttarget_skew\t\t\t\t\tauto\n";
	print {$pnr_f} "set_ccopt_property\ttarget_max_trans\t-net_type\ttop\tauto\n";
	print {$pnr_f} "set_ccopt_property\ttarget_max_trans\t-net_type\ttrunk\tauto\n";
	print {$pnr_f} "set_ccopt_property\ttarget_max_trans\t-net_type\tleaf\tauto\n";
	print {$pnr_f} "set_ccopt_property\tuse_inverters\t\ttrue\n";
	print {$pnr_f} "create_ccopt_clock_tree_spec\t\t-immediate\n";
	print {$pnr_f} "ccoptDesign\n";
	## postCTS Hold.
	print {$pnr_f} "setOptMode\t\t-fixHoldAllowSetupTnsDegrade\tfalse\t\\\n";
	print {$pnr_f} "\t\t\t-ignorePathGroupsForHold\t{default}\n";
	print {$pnr_f} "setOptMode\t\t-addInstancePrefix\t\tpostctshold_\n";
	print {$pnr_f} "set_global\t\ttiming_disable_library_data_to_data_checks\t1\n";
	print {$pnr_f} "set_global\t\ttiming_disable_user_data_to_data_checks\t\t1\n";
	print {$pnr_f} "optDesign\t\t-postCTS \\\n";
	print {$pnr_f} "\t\t\t-hold\n";
	## Route Design.
	print {$pnr_f} "setNanoRouteMode\t-droutePostRouteSpreadWire\tfalse\n";
	print {$pnr_f} "setNanoRouteMode\t-drouteUseMultiCutViaEffort\tlow\n";
	print {$pnr_f} "setDelayCalMode\t\t-SIAware\ttrue\n";
	print {$pnr_f} "setExtractRCMode\t-engine\tpostRoute\t\\\n";
	print {$pnr_f} "\t\t\t-effortLevel\tlow\n";
	print {$pnr_f} "setDelayCalMode\t\t-SIAware\ttrue\n";
	print {$pnr_f} "setAnalysisMode\t\t-analysisType\tonChipVariation\n";
	print {$pnr_f} "route_opt_design\t-setup \\\n";
	print {$pnr_f} "\t\t\t-hold\n";
	print {$pnr_f} "setExtractRCMode\t-effortLevel\tlow\t\t\\\n";
	print {$pnr_f} "\t\t\t-engine\t\tpostRoute\t\\\n";
	print {$pnr_f} "\t\t\t-total_c_th\t0\t\t\\\n";
	print {$pnr_f} "\t\t\t-relative_c_th\t0.03\t\t\\\n";
	print {$pnr_f} "\t\t\t-coupling_c_th\t1\n";
	## Save Design.
	print {$pnr_f} "saveDesign\t\t-rc\t./data/dbs/sign_off_"."$tech_name"."_"."$clk_freq_mhz"."_PG0.enc \\\n";
	print {$pnr_f} "\t\t\t-compress\n";
	## Extract RC.
	print {$pnr_f} "extractRC\n";
	print {$pnr_f} "rcOut\t\t\t-spef\t./data/dbs/sign_off_"."$tech_name"."_"."$clk_freq_mhz"."_PG0.enc.dat/$top_name".".spef.gz\n";
	## Lef/Def Out.
	print {$pnr_f} "set lefDefOutVersion\t5.7\n";
	print {$pnr_f} "defOut\t\t\t-floorplan\t\\\n";
	print {$pnr_f} "\t\t\t-netlist\t./data/dbs/sign_off_"."$tech_name"."_"."$clk_freq_mhz"."_PG0.enc.dat/$top_name.def\n";
	print {$pnr_f} "\n";
#	print {$pnr_f} "deriveTimingBudget\n";
#	print {$pnr_f} "\n";
	print {$pnr_f} "exit\n";

close	$pnr_f;
