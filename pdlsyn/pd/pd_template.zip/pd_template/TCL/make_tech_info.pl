#!/usr/local/bin/perl

use	strict;
use	warnings;

my	$tech_sel;
my	$tech_ans;
my	$db_path;
my	$db;
my	$slib_path;
my	$tech_lef_path;
my	$tech_lef;
my	$cell_lef_path;
my	$cell_lef;
my	$cell_lib_path;
my	$cell_lib;
my	$cap_table;
my	$cell_list_file;

## Tech. Select.
# print	"Select Technology :\n";
# print	"1. TSMC 40nm\n";
# print	"2. TSMC 28nm(HPM)\n";
# $tech_ans = <stdin>;
$tech_ans = "2";
chomp	$tech_ans;	# Remove \n behind $tech_ans.

if( $tech_ans == "1"){

	$tech_sel = "tsmc_40g_sc9_base_rvt";
	$db_path = "/home/gtcad/shared/kchang63/tech/CLN40G/logic/sc9_base_rvt/r2p0/db/";
	$db = "sc9_cln40g_base_rvt_tt_typical_max_0p90v_25c.db";
	$tech_lef_path = "/home/gtcad/shared/kchang63/tech/CLN40G/logic/arm_tech/r3p1/lef/1p9m_6x2z/";
	$tech_lef = "sc9_tech.lef";
	$cell_lef_path = "/home/gtcad/shared/kchang63/tech/CLN40G/logic/sc9_base_rvt/r2p0/lef/";
	$cell_lef = "sc9_cln40g_base_rvt.lef";
	$cap_table = "/home/gtcad/shared/kchang63/tech/CLN40G/logic/arm_tech/r3p1/cadence_captable/1p9m_6x2z/typical.captbl";
	$cell_lib_path = "/home/gtcad/shared/kchang63/tech/CLN40G/logic/sc9_base_rvt/r2p0/lib/";
	$cell_lib = "sc9_cln40g_base_rvt_tt_typical_max_0p90v_25c.lib";
	$cell_list_file = "/home/gtcad/shared/kchang63/tech/CLN40G/logic/sc9_base_rvt/r2p0/doc/sc9_cln40g_base_rvt_cell_list.txt";

}elsif( $tech_ans == "2"){

	$tech_sel = "tsmc_28g_sc9mc_base_svt";
	$db_path = "/home/gtcad/shared/tech/cln28hpm/logic/2d_db/";
	$db = "sc9mc_cln28hpm_base_svt_c38_tt_typical_max_0p90v_25c.db";
	$tech_lef_path = "/home/gtcad/shared/tech/cln28hpm/logic/2d_tech_lef/1p8m_5x2z/";
	$tech_lef = "sc9mc_tech.lef";
	$cell_lef_path = "/home/gtcad/shared/tech/cln28hpm/logic/2d_macro_lef/";
	$cell_lef = "sc9mc_cln28hpm_base_svt_c38.lef";
	$cap_table = "/home/gtcad/shared/tech/cln28hpm/logic/2d_cap/1p8m_5x2z/typical.captbl";
	$cell_lib_path = "/home/gtcad/shared/tech/cln28hpm/logic/2d_lib/";
	$cell_lib = "sc9mc_cln28hpm_base_svt_c38_tt_typical_max_0p90v_25c.lib";
	$cell_list_file = "/home/gtcad/shared/kchang63/tech/CLN28HPM/logic/arm/tsmc/cln28hpm/sc9mc_base_svt_c38/r4p0/doc/sc9mc_cln28hpm_base_svt_c38_cell_list.txt";

}

open	my $tech_info, '>', './INFO/Tech_information';

	## Write DB path.
	print {$tech_info} "Tech name : $tech_sel\n";
	print {$tech_info} "DB path : $db_path\n";
	print {$tech_info} "DB name : $db\n";
	print {$tech_info} "Tech lef path : $tech_lef_path\n";
	print {$tech_info} "Tech lef : $tech_lef\n";
	print {$tech_info} "Cell lef path : $cell_lef_path\n";
	print {$tech_info} "Cell lef : $cell_lef\n";
	print {$tech_info} "Cell lib path : $cell_lib_path\n";
	print {$tech_info} "Cell lib : $cell_lib\n";
	print {$tech_info} "Cap table : $cap_table\n";
	print {$tech_info} "Cell list : $cell_list_file\n";

close	$tech_info;

open	my $inv_list, '>', './INFO/Inverter_list';
	## Write Inverter List
	## Open cell list.
	open	my $inv_info, '<', $cell_list_file || die "Failed to open cell list file.\n";
		while(my $inv_tmp = <$inv_info>){
			if($inv_tmp =~ m/INV/){
				print {$inv_list} "$inv_tmp";
			}else{
				next;
			}
		}
	close	$inv_info;
close	$inv_list;

open	my $buf_list, '>', './INFO/Buffer_list';
	## Write Buffer List
	## Open cell list.
	open	my $buf_info, '<', $cell_list_file || die "Failed to open cell list file.\n";
		while(my $buf_tmp = <$buf_info>){
			if($buf_tmp =~ m/BUF/){
				print {$buf_list} "$buf_tmp";
			}else{
				next;
			}
		}
	close	$buf_info;
close	$buf_list;

