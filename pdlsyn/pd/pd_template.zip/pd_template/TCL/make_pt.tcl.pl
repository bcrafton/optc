#!/usr/local/bin/perl

use	strict;
use	warnings;

my	$rtl_path = "./RTL/";		# RTL path for perl script.
my	$syn_rtl_path = "../RTL/";	# RTL path for synthesis.
my	$syn_path = "../SYN/";		# SYN path for PNR.
my	$pnr_path = "../PNR/";		# PNR path for PT.
my	$verilog_files;			# Name of verilog files.
## Tech. Information.
my	$tech_name;
my	$db_path;
my	$db_name;
my	$tech_lef_path;
my	$tech_lef;
my	$cell_lef_path;
my	$cell_lef;
my	$cell_lib_path;
my	$cell_lib;
my	$cap_tbl;
my	$cell_list;
## Top Module Information.
my	$top_name;
## Clock Information.
my	$clk_freq;
my	$clk_freq_mhz;
my	$clk_period;
my	$clk_name;
my	$rst_name;

## Read Technology Information.
open	my $tech_info, '<', './INFO/Tech_information' || die "Failed to open tech. information file.\n";
	while(my $tech_tmp = <$tech_info>){
		if($tech_tmp =~ m/^Tech name/){		# Tech name.
			chomp $tech_tmp;
			$tech_tmp =~ s/^Tech name : //;
			$tech_name = $tech_tmp;
		}elsif($tech_tmp =~ m/^DB path/){	# DB path.
			chomp $tech_tmp;
			$tech_tmp =~ s/^DB path : //;
			$db_path = $tech_tmp;
		}elsif($tech_tmp =~ m/^DB name/){	# DB name.
			chomp $tech_tmp;
			$tech_tmp =~ s/^DB name : //;
			$db_name = $tech_tmp;
		}elsif($tech_tmp =~ m/^Tech lef path/){	# Tech. lef path.
			chomp $tech_tmp;
			$tech_tmp =~ s/^Tech lef path : //;
			$tech_lef_path = $tech_tmp;
		}elsif($tech_tmp =~ m/^Tech lef/){	# Tech. lef.
			chomp $tech_tmp;
			$tech_tmp =~ s/^Tech lef : //;
			$tech_lef = $tech_tmp;
		}elsif($tech_tmp =~ m/^Cell lef path/){	# Cell lef path.
			chomp $tech_tmp;
			$tech_tmp =~ s/Cell lef path : //;
			$cell_lef_path = $tech_tmp;
		}elsif($tech_tmp =~ m/^Cell lef/){	# Cell lef.
			chomp $tech_tmp;
			$tech_tmp =~ s/^Cell lef : //;
			$cell_lef = $tech_tmp;
		}elsif($tech_tmp =~ m/^Cell lib path/){	# Cell lib path.
			chomp $tech_tmp;
			$tech_tmp =~ s/^Cell lib path : //;
			$cell_lib_path = $tech_tmp;
		}elsif($tech_tmp =~ m/^Cell lib/){	# Cell lib.
			chomp $tech_tmp;
			$tech_tmp =~ s/Cell lib : //;
			$cell_lib = $tech_tmp;
		}elsif($tech_tmp =~ m/^Cap table/){	# Cap table.
			chomp $tech_tmp;
			$tech_tmp =~ s/^Cap table : //;
			$cap_tbl = $tech_tmp;
		}elsif($tech_tmp =~ m/^Cell list/){	# Cell list.
			chomp $tech_tmp;
			$tech_tmp =~ s/^Cell list : //;
			$cell_list = $tech_tmp;
		}else{
			print	"$tech_tmp\n";
			die "Failed to read tech. information file.\n";
		}
	}
close	$tech_info;
## Read Top Module Name.
open	my $top_m_info, '<', './INFO/Module_hierarchy' || die "Failed to open top module information file.\n";
	while(my $top_tmp = <$top_m_info>){
		chomp $top_tmp;
		if($top_tmp =~ m/Top module name/){
			$top_tmp =~ s/Top module name : //;
			$top_name = $top_tmp;
		}
	}
close	$top_m_info;
## Read Clock Information.
open	my $clk_info, '<', './INFO/Clk_information' || die "Failed to open clock information file.\n";
	while(my $clk_tmp = <$clk_info>){
		if($clk_tmp =~ m/^Clk freq./){		# Clock frequency.
			chomp $clk_tmp;
			$clk_tmp =~ s/^Clk freq. : //;
			$clk_freq = $clk_tmp;
		}elsif($clk_tmp =~ m/^Clk period/){	# Clock period.
			chomp $clk_tmp;
			$clk_tmp =~ s/^Clk period : //;
			$clk_period = $clk_tmp;
		}elsif($clk_tmp =~ m/^Clk name/){	# Clock name.
			chomp $clk_tmp;
			$clk_tmp =~ s/^Clk name : //;
			$clk_name = $clk_tmp;
		}elsif($clk_tmp =~ m/^Reset name/){	# Reset name.
			chomp $clk_tmp;
			$clk_tmp =~ s/^Reset name : //;
			$rst_name = $clk_tmp;
		}else{
			die "Failed to read clock information file.\n";
		}
	}
	$clk_freq_mhz = $clk_freq * 1000;
close	$clk_info;		
	
my	$pnr_data_path = "data/dbs/sign_off_"."$tech_name"."_"."$clk_freq_mhz"."_PG0.enc.dat/";

## Write Prime-Time Run File.
open	my $pt_f, '>', './PT/pt.tcl';
	## Set input verilog file.(Synthesis result)
	print {$pt_f} "set search_path\t\t[concat\t. \\\n";
	print {$pt_f} "\t\t\t\t\t$db_path \\\n";
	print {$pt_f} "\t\t\t\t\t$syn_rtl_path \\\n";
	print {$pt_f} "\t\t\t\t]\n";
	print {$pt_f} "set link_library\t\t[concat\t* \\\n";
	print {$pt_f} "\t\t\t\t\t$db_name \\\n";
	print {$pt_f} "\t\t\t\t]\n";
	print {$pt_f} "set symbol_library\t\t{}\n";
	print {$pt_f} "set target_library\t\t[concat $db_name]\n";
	print {$pt_f} "read_verilog\t\t\t"."$pnr_path"."$pnr_data_path"."$top_name.v.gz\n";
	print {$pt_f} "set_design_top\t\t\t$top_name\n";
	print {$pt_f} "read_parasitics\t\t\t"."$pnr_path"."$pnr_data_path"."$top_name.spef.gz\n";
	print {$pt_f} "complete_net_parasitics\t\t-complete_with\tzero\n";
	print {$pt_f} "report_annotated_parasitics\t-check\n";
	print {$pt_f} "source\t$syn_path"."$top_name"."_SYN.sdc\n";
	print {$pt_f} "set timing_save_pin_arrival_and_slack\t\ttrue\n";
	print {$pt_f} "set timing_save_pin_arrival_and_required\ttrue\n";
	print {$pt_f} "report_units\n";
	print {$pt_f} "report_timing\t\t-nets \\\n";
	print {$pt_f} "\t\t\t-nosplit \\\n";
	print {$pt_f} "\t\t\t-capacitance \\\n";
	print {$pt_f} "\t\t\t-transition_time \\\n";
	print {$pt_f} "\t\t\t-input_pins \\\n";
	print {$pt_f} "\t\t\t-significant_digits\t6\n";
	print {$pt_f} "report_clock_timing\t-type\tsummary \\\n";
	print {$pt_f} "\t\t\t-significant_digits\t6 \\\n";
	print {$pt_f} "\t\t\t-nosplit\n";

	print {$pt_f} "puts \"Performing Power Analysis\"\n";
	print {$pt_f} "set power_enable_analysis\ttrue\n";
	print {$pt_f} "set power_analysis_mode\taveraged\n";
	print {$pt_f} "set power_clock_network_include_register_clock_pin_power\tfalse\n";

	print {$pt_f} "set thisSeqOut\t[all_registers\t-output_pins]\n";
	print {$pt_f} "set thisIp\t[all_inputs]\n";
	print {$pt_f} "set thisClkPort\t[get_ports\t-filter\t{is_clock_used_as_clock == true}]\n";
	print {$pt_f} "if { [sizeof_collection \$thisSeqOut] > 0 } {\n";
	print {$pt_f} "\tset_switching_activity \$thisSeqOut -static_probability 0.5 -toggle_rate 0.3 -base_clock [get_clock]\n";
	print {$pt_f} "}\n";
	print {$pt_f} "if { [sizeof_collection \$thisIp] > 0 } {\n";
	print {$pt_f} "\tset_switching_activity \$thisIp -static_probability 0.5 -toggle_rate 0.2 -base_clock [get_clock]\n";
	print {$pt_f} "}\n";
	print {$pt_f} "if { [sizeof_collection \$thisClkPort] > 0 } {\n";
	print {$pt_f} "\tset_switching_activity \$thisClkPort -static_probability 0.5 -toggle_rate 0.2 -base_clock [get_clock]\n";
	print {$pt_f} "}\n";

	print {$pt_f} "update_power\n";
	print {$pt_f} "report_switching_activity\n";
	print {$pt_f} "report_power\t-verbose\n";
	
	print {$pt_f} "source\t./pt_procs.tcl\n";

	print {$pt_f} "cell_count\n";
	print {$pt_f} "FF_count\n";
	print {$pt_f} "clock_period\n";
	print {$pt_f} "WNS\n";
	print {$pt_f} "TNS\n";
	print {$pt_f} "TPS\n";
	print {$pt_f} "total_power\n";
	print {$pt_f} "switching_power\n";
	print {$pt_f} "internal_power\n";
	print {$pt_f} "FF_total_power\n";
	print {$pt_f} "clk_total_power\n";
	print {$pt_f} "cap_analysis\n";
	print {$pt_f} "sw_int\n";
	print {$pt_f} "close_file\n";
	print {$pt_f} "\n";
	print {$pt_f} "exit\n";
	
close	$pt_f;
