#!/usr/local/bin/perl

use	strict;
use	warnings;

my	$rtl_path = "./RTL/";		# RTL path for perl script.
my	$syn_rtl_path = "../RTL/";	# RTL path for synthesis
my	$verilog_files;			# Name of verilog files.
## Tech. Information.
my	$tech_name;
my	$db_path;
my	$db_name;
my	$tech_lef_path;
my	$tech_lef;
my	$cell_lef_path;
my	$cell_lef;
my	$cell_lib_path;
my	$cell_lib;
my	$cap_tbl;
my	$cell_list;
## Top Module Information.
my	$top_name;
## Clock Information.
my	$clk_freq;
my	$clk_period;
my	$clk_name;
my	$rst_name;

## Read Technology Information.
open	my $tech_info, '<', './INFO/Tech_information' || die "Failed to open tech. information file.\n";
	while(my $tech_tmp = <$tech_info>){
		if($tech_tmp =~ m/^Tech name/){		# Tech name.
			chomp $tech_tmp;
			$tech_tmp =~ s/^Tech name : //;
			$tech_name = $tech_tmp;
		}elsif($tech_tmp =~ m/^DB path/){	# DB path.
			chomp $tech_tmp;
			$tech_tmp =~ s/^DB path : //;
			$db_path = $tech_tmp;
		}elsif($tech_tmp =~ m/^DB name/){	# DB name.
			chomp $tech_tmp;
			$tech_tmp =~ s/^DB name : //;
			$db_name = $tech_tmp;
		}elsif($tech_tmp =~ m/^Tech lef path/){	# Tech. lef path.
			chomp $tech_tmp;
			$tech_tmp =~ s/^Tech lef path : //;
			$tech_lef_path = $tech_tmp;
		}elsif($tech_tmp =~ m/^Tech lef/){	# tech. lef.
			chomp $tech_tmp;
			$tech_tmp =~ s/^Tech lef : //;
			$tech_lef = $tech_tmp;
		}elsif($tech_tmp =~ m/^Cell lef path/){	# Cell lef path.
			chomp $tech_tmp;
			$tech_tmp =~ s/Cell lef path : //;
			$cell_lef_path = $tech_tmp;
		}elsif($tech_tmp =~ m/^Cell lef/){	# Cell lef.
			chomp $tech_tmp;
			$tech_tmp =~ s/^Cell lef : //;
			$cell_lef = $tech_tmp;
		}elsif($tech_tmp =~ m/^Cell lib path/){	# Cell lib path.
			chomp $tech_tmp;
			$tech_tmp =~ s/^Cell lib path : //;
			$cell_lib_path = $tech_tmp;
		}elsif($tech_tmp =~ m/^Cell lib/){	# Cell lib.
			chomp $tech_tmp;
			$tech_tmp =~ s/Cell lib : //;
			$cell_lib = $tech_tmp;
		}elsif($tech_tmp =~ m/^Cap table/){	# Cap table.
			chomp $tech_tmp;
			$tech_tmp =~ s/^Cap table : //;
			$cap_tbl = $tech_tmp;
		}elsif($tech_tmp =~ m/^Cell list/){	# Cell list.
			chomp $tech_tmp;
			$tech_tmp =~ s/^Cell list : //;
			$cell_list = $tech_tmp;
		}else{
			print	"$tech_tmp\n";
			die "Failed to read tech. information file.\n";
		}
	}
close	$tech_info;
## Read Top Module Name.
open	my $top_m_info, '<', './INFO/Module_hierarchy' || die "Failed to open top module information file.\n";
	while(my $top_tmp = <$top_m_info>){
		chomp $top_tmp;
		if($top_tmp =~ m/^Top module name/){
			$top_tmp =~ s/Top module name : //;
			$top_name = $top_tmp;
		}
	}
close	$top_m_info;
## Read Clock Information.
open	my $clk_info, '<', './INFO/Clk_information' || die "Failed to open clock information file.\n";
	while(my $clk_tmp = <$clk_info>){
		if($clk_tmp =~ m/^Clk freq./){		# Clock frequency.
			chomp $clk_tmp;
			$clk_tmp =~ s/^Clk freq. : //;
			$clk_freq = $clk_tmp;
		}elsif($clk_tmp =~ m/^Clk period/){	# Clock period.
			chomp $clk_tmp;
			$clk_tmp =~ s/^Clk period : //;
			$clk_period = $clk_tmp;
		}elsif($clk_tmp =~ m/^Clk name/){	# Clock name.
			chomp $clk_tmp;
			$clk_tmp =~ s/^Clk name : //;
			$clk_name = $clk_tmp;
		}elsif($clk_tmp =~ m/^Reset name/){	# Reset name.
			chomp $clk_tmp;
			$clk_tmp =~ s/^Reset name : //;
			$rst_name = $clk_tmp;
		}else{
			die "Failed to read clock information file.\n";
		}
	}
close	$clk_info;		
	
## Write Synthesis Run File.
open	my $syn_f, '>', './SYN/syn.tcl';
	## Set search path.
	print {$syn_f} "set search_path\t\t[concat\t. \\\n";
	print {$syn_f} "\t\t\t\t$db_path \\\n";
	print {$syn_f} "\t\t\t\t$syn_rtl_path \\\n";
	print {$syn_f} "\t\t\t]\n";
	## Set link library.
	print {$syn_f} "set link_library\t[concat\t* \\\n";
	print {$syn_f} "\t\t\t\t$db_name \\\n";
	print {$syn_f} "\t\t\t\tdw_foundation.sldb \\\n";
	print {$syn_f} "\t\t\t]\n";
	## Set symbol library.
	print {$syn_f} "set symbol_library\t{}\n";
	## Set target library.
	print {$syn_f} "set target_library\t[concat\t\\\n";
	print {$syn_f} "\t\t\t\t$db_name \\\n";
	print {$syn_f} "\t\t\t]\n";
	## Set verilog files.
	print {$syn_f} "set verilog_files\t[list\t\\\n";
	## Read a list of verilog files.
	opendir (dirHandle, $rtl_path) || die "Failed to get verilog files.\n";
		while($verilog_files = readdir(dirHandle)){
			# Use regular expression to ignore files beginning with a period.
			next if($verilog_files =~ m/^\./);
			print {$syn_f} "\t\t\t\t$verilog_files \\\n";
	}
	closedir (dirHandle);
	print {$syn_f} "\t\t\t]\n";
	print {$syn_f} "analyze\t\t\t-format\tverilog \$verilog_files\n";
	print {$syn_f} "elaborate\t\t$top_name\n";
	print {$syn_f} "link\n";
	## Set clock information.
	print {$syn_f} "set clk_freq\t\t$clk_freq\n";
	print {$syn_f} "set clk_period\t\t$clk_period\n";
	print {$syn_f} "create_clock\t\t[get_ports $clk_name] \\\n";
	print {$syn_f} "\t\t\t-period\t$clk_period\n";
	print {$syn_f} "set_max_fanout\t\t20 \\\n";
	print {$syn_f} "\t\t\t[get_ports $clk_name]\n";
	print {$syn_f} "set_ideal_network\t[get_ports $clk_name]\n";
	## Set reset information.
	print {$syn_f} "set_max_fanout\t\t20 \\\n";
	print {$syn_f} "\t\t\t[get_ports $rst_name]\n";
	print {$syn_f} "set_false_path\t\t-from\t[get_ports $rst_name]\n";

	print {$syn_f} "compile_ultra\t\t-no_autoungroup\n";
#	print {$syn_f} "uniquify\n";
	print {$syn_f} "define_name_rules\tverilog \\\n";
	print {$syn_f} "\t\t\t-remove_internal_net_bus \\\n";
	print {$syn_f} "\t\t\t-remove_port_bus\n";
	## Set output file information.
	print {$syn_f} "write\t\t\t-hierarchy \\\n";
	print {$syn_f} "\t\t\t-format\tverilog \\\n";
	print {$syn_f} "\t\t\t-output\t$top_name"."_SYN.v\n";
	print {$syn_f} "remove_ideal_network\t[get_ports $clk_name]\n";
	print {$syn_f} "set_propagated_clock\t[get_ports $clk_name]\n";
	print {$syn_f} "write_sdc\t\t\t-version\t1.9 \\\n";
	print {$syn_f} "\t\t\t$top_name"."_SYN.sdc\n";

	print {$syn_f} "\n";
	print {$syn_f} "exit";

close	$syn_f;
