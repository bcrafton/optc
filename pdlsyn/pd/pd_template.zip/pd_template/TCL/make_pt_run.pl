#!/usr/local/bin/perl

use	strict;
use	warnings;

open	my $run_file, '>', './PT/:run_pt';
	
	print {$run_file} "source /tools/synopsys/primetime/f201106sp32/cshrc.prime\n";
	print {$run_file} "pt_shell -f pt.tcl | tee pt.log\n";

close	$run_file;
