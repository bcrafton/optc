#!/usr/local/bin/perl

use	strict;
use	warnings;

open	my $run_file, '>', './SYN/:run_syn';
	
	## Write clock information.
	print {$run_file} "source /tools/synopsys/synthesis/j201409sp3/cshrc.syn\n";
	print {$run_file} "dc_shell -f syn.tcl -output_log_file syn.log\n";

close	$run_file;
