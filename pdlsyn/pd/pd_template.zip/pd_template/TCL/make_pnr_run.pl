#!/usr/local/bin/perl

use	strict;
use	warnings;

open	my $run_file, '>', './PNR/:run_pnr';
	
	print {$run_file} "source /tools/cadence/innovus151/cshrc.meta\n";
	print {$run_file} "innovus -64 -init pnr.tcl -log pnr.log\n";

close	$run_file;
